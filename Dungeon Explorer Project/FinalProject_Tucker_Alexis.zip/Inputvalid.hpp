/*************************************************************************
**Program Name: Final Project
**Author: Alexis Tucker
**Date: 3/16/18
**Description: Header for the inputValid function which tests user input 
** to see if it is valid.
*************************************************************************/
#ifndef INPUTVALID_HPP
#define INPUTVALID_HPP

bool inputValid(int c);

#endif
